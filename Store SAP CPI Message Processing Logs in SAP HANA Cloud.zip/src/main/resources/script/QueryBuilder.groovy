import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
	
	def xml = new XmlSlurper().parseText(message.getBody(String))
    
    def prop = message.getProperties();
    def tableName = prop.get("TableName");
    
	// Get Table Name
	def temptableName = "\"${tableName}\""

	// Start SQL statement
	def sqlQuery = "INSERT INTO ${temptableName} (\"MessageID\", \"CorrelationID\", \"ApplicationMessageId\", \"Status\", \"IntegrationFlowName\", \"PackageName\", \"LogTime\", \"ExceptionMessage\", \"MonitorLink\") \n"

	// Generate SELECT statements
	def selects = xml.Records.collect { log ->
	"""SELECT '${log.MessageID.text()}', '${log.CorrelationID.text()}', '${log.ApplicationMessageId.text()}', '${log.Status.text()}', '${log.IntegrationFlowName.text()}', '${log.PackageName.text()}', '${log.LogTime.text()}', '${log.ExceptionMessage.text().replace("'", "''")}', '${log.MonitorLink.text()}' FROM DUMMY"""
	}

	// Combine SELECTs with UNION ALL
	sqlQuery += selects.join("\nUNION ALL\n") + ";"

	// Set the generated SQL as the message body
	message.setBody(sqlQuery.toString());
	return message
}